"""OCR Service application package."""
